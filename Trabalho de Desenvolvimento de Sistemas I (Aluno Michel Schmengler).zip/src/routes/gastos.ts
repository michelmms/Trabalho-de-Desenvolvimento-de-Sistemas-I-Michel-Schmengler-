// src/routes/gastos.ts
import { Router, Request, Response } from 'express';
import { getRepository } from 'typeorm';
import { Gasto } from '../entities/Gasto';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  const gastoRepository = getRepository(Gasto);
  const gastos = await gastoRepository.find();
  res.json(gastos);
});

router.post('/', async (req: Request, res: Response) => {
  const { descricao, valor, data, categorias } = req.body;

  const gastoRepository = getRepository(Gasto);
  const gasto = new Gasto();
  gasto.descricao = descricao;
  gasto.valor = valor;
  gasto.data = data;
  gasto.categorias = categorias;

  await gastoRepository.save(gasto);
  res.sendStatus(201);
});

router.put('/:id', async (req: Request, res: Response) => {
  const { id } = req.params;
  const { descricao, valor, data, categorias } = req.body;

  const gastoRepository = getRepository(Gasto);
  const gasto = await gastoRepository.findOne(id);

  if (!gasto) {
    return res.sendStatus(404);
  }

  gasto.descricao = descricao;
  gasto.valor = valor;
  gasto.data = data;
  gasto.categorias = categorias;

  await gastoRepository.save(gasto);
  res.sendStatus(204);
});

router.delete('/:id', async (req: Request, res: Response) => {
  const { id } = req.params;

  const gastoRepository = getRepository(Gasto);
  const gasto = await gastoRepository.findOne(id);

  if (!gasto) {
    return res.sendStatus(404);
  }

  await gastoRepository.remove(gasto);
  res.sendStatus(204);
});

export default router;
