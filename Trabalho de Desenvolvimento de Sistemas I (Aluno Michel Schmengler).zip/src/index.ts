// src/index.ts
import express from 'express';
import { createConnection } from 'typeorm';
import gastosRouter from './routes/gastos';

const app = express();
app.use(express.json());

app.use('/gastos', gastosRouter);

createConnection()
  .then(() => {
    app.listen(3000, () => {
      console.log('Server started on port 3000');
    });
  })
  .catch((error) => console.log(error));
