// src/entities/GastoCategoria.ts
import { Entity, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Gasto } from './Gasto';
import { Categoria } from './Categoria';

@Entity({ name: 'Gastos_Categorias' })
export class GastoCategoria {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Gasto, gasto => gasto.categorias)
  @JoinColumn({ name: 'id_gasto' })
  gasto: Gasto;

  @ManyToOne(() => Categoria, categoria => categoria.gastos)
  @JoinColumn({ name
