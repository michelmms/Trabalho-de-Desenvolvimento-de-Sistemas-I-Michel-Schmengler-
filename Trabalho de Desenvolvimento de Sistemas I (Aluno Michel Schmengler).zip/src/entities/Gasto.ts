// src/entities/Gasto.ts
import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable } from 'typeorm';
import { Categoria } from './Categoria';

@Entity()
export class Gasto {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  descricao: string;

  @Column()
  valor: number;

  @Column()
  data: Date;

  @ManyToMany(() => Categoria)
  @JoinTable({ name: 'Gastos_Categorias' })
  categorias: Categoria[];
}