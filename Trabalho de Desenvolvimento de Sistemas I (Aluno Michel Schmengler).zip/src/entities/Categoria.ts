// src/entities/Categoria.ts
import { Entity, PrimaryGeneratedColumn, Column, ManyToMany } from 'typeorm';
import { Gasto } from './Gasto';

@Entity()
export class Categoria {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nome: string;

  @ManyToMany(() => Gasto, gasto => gasto.categorias)
  gastos: Gasto[];
}
