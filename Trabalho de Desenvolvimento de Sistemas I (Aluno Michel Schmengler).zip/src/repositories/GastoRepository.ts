// src/repositories/GastoRepository.ts
import { EntityRepository, Repository } from 'typeorm';
import { Gasto } from '../entities/Gasto';

@EntityRepository(Gasto)
export class GastoRepository extends Repository<Gasto> {}
